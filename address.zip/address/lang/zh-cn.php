<?php

return [
    'Please configure the corresponding map key first' => '请先配置对应地图的密钥'
];
